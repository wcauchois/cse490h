#!/bin/bash

javac -cp ./jars/plume.jar proj/*.java

exit
