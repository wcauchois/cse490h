import edu.washington.cs.cse490h.lib.Utility;

/**
 * The set of client RPC methods (and stubs => re: sendCallPacket)  
 *
 */
public class RPCClient {
    private RPCNode n;
    
    /**
     * Constructor
     * 
     * @param n a reference to the user of these RPCs
     */
    public RPCClient(RPCNode n) {
        this.n = n;
    }
    
    /**
     * This command creates an empty fille called filename on dest
     * 
     * @param dest
     * @param filename
     */
    public void callCreate(int dest, String filename) {
        String payload = "create " + filename;
        sendCallPacket(dest, payload);
    }
    
    /**
     * Get a file from a server. This returns the file in its entirety. The client
     * then prints this file to the console.
     * 
     * @param dest
     * @param filename
     */
    public void callGet(int dest, String filename) {
        String payload = "get " + filename;
        sendCallPacket(dest, payload);
    }
    
    /**
     * Write the contents to a file on a server. This should only work
     * on an already created file, and should replace the existing contents
     * of that file.
     * 
     * @param dest
     * @param filename
     * @param contents
     */
    public void callPut(int dest, String filename, String contents) {
        String payload = "put " + filename + " " + contents;
        if(payload.length() > RPCPacket.MAX_PAYLOAD_SIZE) {
        	// This didn't really come from the server, but same difference...
        	n.onRPCError(dest, "append", filename, RPCPacket.ERR_FILE_TOO_LARGE, "File too large");
            return;
        }
        sendCallPacket(dest, payload);
    }
    
    /**
     * Append contents to a file on a server. This should only work
     * on an already created file, and should be appended to the end
     * of the existing file.
     * 
     * @param dest
     * @param filename
     * @param contents
     */
    public void callAppend(int dest, String filename, String contents) {
        String payload = "append " + filename + " " + contents;
        if(payload.length() > RPCPacket.MAX_PAYLOAD_SIZE) {
        	// This didn't really come from the server, but same difference...
        	n.onRPCError(dest, "append", filename, RPCPacket.ERR_FILE_TOO_LARGE, "File too large");
            return;
        }
        sendCallPacket(dest, payload);
    }
    
    /**
     * This command deletes the file called filename on dest.
     * 
     * @param dest
     * @param filename
     */
    public void callDelete(int dest, String filename) {
         String payload = "delete " + filename;
         sendCallPacket(dest, payload);
    }
    
    /**
     * Our RPC Stub
     * TODO: use protobuffers
     * 
     * @param dest
     * @param payload
     */
    private void sendCallPacket(int dest, String payload) {
        RPCPacket callPkt = new RPCPacket(RPCPacket.CALL, 0, Utility.stringToByteArray(payload));
        n.RIOSend(dest, AppProtocol.RPC, callPkt.pack());
    }
    
    /**
     * Receive an RPC return packet
     * 
     * @param from
     * @param pkt
     * 
     *  precondition: pkt.getType() == RPCPacket.RESULT
     */
    public void onRPCReceive(int from, RPCPacket pkt) {
        String payload = Utility.byteArrayToString(pkt.getPayload());
        String[] components = payload.split(" ");

        if(pkt.getErrorCode() != 0) {
        	n.onRPCError(from, components[0], components[1], pkt.getErrorCode(), pkt.getErrorMessage());
            return;
        }
        
        String result = "";
        if(components[0].equals("get")) {
        	// components[2] might be invalid, since we just used split which will not include spaces
        	// in the result. Re-parse the payload using AppUtil.splitArgs.
        	components = AppUtil.splitArgs(payload, 3);
        	result = components[2];
        }
        n.onRPCSuccess(from, components[0], components[1], result);
    }
}
