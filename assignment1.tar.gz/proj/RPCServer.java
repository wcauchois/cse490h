import java.io.IOException;

import edu.washington.cs.cse490h.lib.PersistentStorageReader;
import edu.washington.cs.cse490h.lib.PersistentStorageWriter;
import edu.washington.cs.cse490h.lib.Utility;

/**
 * The set of server RPC methods (and stubs: re onRPCReceive)
 *
 */
public class RPCServer {
    private RPCNode n;

    /**
     * Constructor
     * @param n our parent node.
     */
    public RPCServer(RPCNode n) {
        this.n = n;
    }
    
    /**
     * Initialize the RPC server (call this in Node.start() to ensure consistent state).
     */
    public void start() {
    	if(Utility.fileExists(n, ".temp")) {
    		try {
    			PersistentStorageReader tempReader = n.getReader(".temp");
    			if(tempReader.ready()) {
    				String filename = tempReader.readLine();
    				String oldContents = getContents(tempReader);
    				PersistentStorageWriter revertFile = n.getWriter(filename, false);
    				revertFile.write(oldContents);
    			}
    			tempReader.close();
    			n.getWriter(".temp", false).delete();
    		} catch(IOException e) { }
    	}
    }
    
    /**
     * Receive a CALL packet and perform the function indicated.
     * @param from who to send the RESULT packet to.
     * @param packet the CALL packet
     * @return the command we just executed, or "ERROR command" indicating an error occurred while
     * 			executing the specified command.
     * precondition: packet.getType() == RPCPacket.CALL
     */
    public String onRPCReceive(int from, RPCPacket packet) {
    	if(packet.getType() != RPCPacket.CALL) {
    		throw new RuntimeException("RPCServer can only handle CALL packets");
    	}
    	
    	String command = Utility.byteArrayToString(packet.getPayload());
    	
    	String result = "";
    	String[] args = null;
    	int errorCode = 0; // success
    	
    	try {
    		
			if (command.startsWith("create ")) { // create filename
	        	args = AppUtil.splitArgs(command, 2);
	        	result = doCreate(args[1]);
	        	
	        } else if (command.startsWith("get ")) { // get filename
	        	args = AppUtil.splitArgs(command, 2);
	        	result = doGet(args[1]);
	        	
	        } else if (command.startsWith("put ")) { // put filename contents
	        	args = AppUtil.splitArgs(command, 3);
	        	result = doPut(args[1], args[2]);
	        	
	        } else if (command.startsWith("append ")) { // append filename contents
	        	args = AppUtil.splitArgs(command, 3);
	        	result = doAppend(args[1], args[2]);
	        	
	        } else if (command.startsWith("delete ")) { // delete filename
	        	args = AppUtil.splitArgs(command, 2);
	        	result = doDelete(args[1]);
	        }
    	} catch(RPCError err) {
    		errorCode = err.code;
    		result = "";
    	}
    	String method = args[0], filename = args[1];
		
    	String resultString = method + " " + filename + " " + result;
    	RPCPacket resultPacket = new RPCPacket(RPCPacket.RESULT, errorCode,
    			Utility.stringToByteArray(resultString));
    	n.RIOSend(from, AppProtocol.RPC, resultPacket.pack());
    	
    	if(errorCode == 0)
    		return method;
    	else
    		return "ERROR " + method;
    }
    
    // Thrown from the do* methods to indicate an error has occurred.
    @SuppressWarnings("serial")
	private class RPCError extends Exception {
		public int code;
    	public RPCError(int code) {
    		this.code = code;
    	}
    }
    
    // Called for the CREATE command to create a file.
    private String doCreate(String filename) throws RPCError {
    	if(Utility.fileExists(n, filename)) {
    		throw new RPCError(RPCPacket.ERR_FILE_EXISTS);
    	}
    	try {
    		// just getting a writer for filename should serve to create the file
    		n.getWriter(filename, false).close();
    	} catch(IOException e) {
    		throw new RPCError(RPCPacket.ERR_IO_EXCEPTION);
    	}
    	return "";
    }
    
    // Called for the GET command to get the contents of a file.
    private String doGet(String filename) throws RPCError {
    	if(!Utility.fileExists(n, filename)) {
    		throw new RPCError(RPCPacket.ERR_FILE_NOT_FOUND);
    	}
    	try {
    		PersistentStorageReader reader = n.getReader(filename);
    		String result = getContents(reader);
    		reader.close();
    		if((result + "get " + filename + " ").length() > RPCPacket.MAX_PAYLOAD_SIZE) {
    			throw new RPCError(RPCPacket.ERR_FILE_TOO_LARGE);
    		}
    		return result;
    	} catch(IOException e) {
    		throw new RPCError(RPCPacket.ERR_IO_EXCEPTION);
    	}
    }
    
    // Called for the PUT command to put stuff in a file.
    private String doPut(String filename, String contents) throws RPCError {
    	if(!Utility.fileExists(n, filename)) {
    		throw new RPCError(RPCPacket.ERR_FILE_NOT_FOUND);
    	}
    	try {
    		// Vincent's magical error-proof put method
    		String oldContents = getContents(n.getReader(filename));
    		PersistentStorageWriter tempWriter = n.getWriter(".temp", false);
    		tempWriter.write(filename + "\n" + oldContents);
    		PersistentStorageWriter newFile = n.getWriter(filename, false);
    		newFile.write(contents);
    		tempWriter.delete();
    		newFile.close();
    	} catch(IOException e) {
    		throw new RPCError(RPCPacket.ERR_IO_EXCEPTION);
    	}
    	return "";
    }
    
    // Called for the APPEND command to append stuff to the end of a file.
    private String doAppend(String filename, String contents) throws RPCError {
    	if(!Utility.fileExists(n, filename)) {
    		throw new RPCError(RPCPacket.ERR_FILE_NOT_FOUND);
    	}
    	try {
    		PersistentStorageWriter writer = n.getWriter(filename, true);
    		writer.write(contents);
    		writer.close();
    	} catch(IOException e) {
    		throw new RPCError(RPCPacket.ERR_IO_EXCEPTION);
    	}
    	return "";
    }
    
    // Called for the DELETE command to delete a file.
    private String doDelete(String filename) throws RPCError {
    	if(!Utility.fileExists(n, filename)) {
    		throw new RPCError(RPCPacket.ERR_FILE_NOT_FOUND);
    	}
    	try {
    		PersistentStorageWriter writer = n.getWriter(filename, false);
    		writer.delete();
    	} catch(IOException e) {
    		throw new RPCError(RPCPacket.ERR_IO_EXCEPTION);
    	}
    	return "";
    }
    
    // Read everything from a stream and put it into a buffer.
    private String getContents(PersistentStorageReader reader) throws IOException {
    	StringBuffer contents = new StringBuffer();
    	char[] buffer = new char[1024];
		int bytesRead = 0;
		while(bytesRead >= 0) {
			bytesRead = reader.read(buffer, 0, 1024);
			if(bytesRead > 0)
				contents.append(buffer, 0, bytesRead);
		}
		return contents.toString();
    }
}
