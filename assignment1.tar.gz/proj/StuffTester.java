import java.util.*;
public class StuffTester {
	public static void main(String[] args) {
		System.out.println(Arrays.toString(AppUtil.splitArgs("get foo.txt ", 3)));
	}
}
