class TransmissionProtocol {
	public static final int RIO = 0;
	
	public static final int MAX_PROTOCOL = 127;
}

class AppProtocol {
	public static final int SIMPLESEND_PKT = 9;
	public static final int RIOTEST_PKT = 10;
	public static final int RPC = 11;
	
	public static final int MAX_PROTOCOL = 127;
}
