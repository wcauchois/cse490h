import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;


/**
 * This conveys the data necessary for an RPC  call or return. This is
 * carried in the payload of an RIOPacket.
 */
public class RPCPacket {
    public static final int HEADER_SIZE = 2;
    public static final int MAX_PAYLOAD_SIZE = RIOPacket.MAX_PAYLOAD_SIZE - HEADER_SIZE;
    
    public static final int CALL = 0;
    public static final int RESULT = 1;
    
    public static final int ERR_FILE_NOT_FOUND = 10;
    public static final int ERR_FILE_EXISTS = 11;
    public static final int ERR_IO_EXCEPTION = 12;
    public static final int ERR_TIMEOUT = 20;
    public static final int ERR_FILE_TOO_LARGE = 30;

    private byte type;
    private byte errorCode;
    private byte[] payload;
    
    /**
     * 
     * @param type whether the packet is a call or a return
     * @param errorCode if this is an RPC return, indicates what the error code was
     * @param payload the arguments or return contents for the RPC call
     */
    public RPCPacket(int type, int errorCode, byte[] payload) {
        if (payload.length > MAX_PAYLOAD_SIZE) {
            throw new IllegalArgumentException("Illegal arguments given to RIOPacket");
        }
        
        this.type = (byte)type;
        this.errorCode  = (byte)errorCode;
        this.payload = payload;
    }
    
    /**
     * @return either RPCPacket.CALL or RPCPacket.RESULT.
     */
    public int getType() {
    	return type;
    }
    
    /**
     * @return if this is an RPC return, indicates what the error code was
     */
    public int getErrorCode() {
    	return errorCode;
    }
    
    /**
     * @return A String message for the error code of this RPC return, or an empty string
     *                 if the error code was 0.
     */
    public String getErrorMessage() {
        switch(errorCode) {
        case ERR_FILE_NOT_FOUND:	return "File does not exist";
        case ERR_FILE_EXISTS:		return "File already exists";
        case ERR_TIMEOUT:			return "Timeout";
        case ERR_FILE_TOO_LARGE:	return "File too large";
        case ERR_IO_EXCEPTION:		return "Unspecified IO exception";
        default:					return "Unknown";
        }
    }
    
    /**
     * @return the arguments or return contents for the RPC call
     */
    public byte[] getPayload() {
    	return payload;
    }
    
    /**
     * Unpack the byte stream into an RPCPacket
     * 
     * @param packet
     * @return a new RPCPacket
     * 
     * precondition: packet is encoded as an RPC packet
     */
    public static RPCPacket unpack(byte[] packet) {
        try {
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(packet));

            byte type = in.readByte();
            byte errorCode = in.readByte();
    
            byte[] payload = new byte[packet.length - HEADER_SIZE];
            if(payload.length > 0) {
                int bytesRead = in.read(payload, 0, payload.length);
                if (bytesRead != payload.length) {
                    return null;
                }
            }
            
            return new RPCPacket(type, errorCode, payload);
        } catch (IllegalArgumentException e) {
            // will return null
        } catch(IOException e) {
            // will return null
        }
        return null;
    }
    
    /**
     * Serialize the RPCPacket
     * TODO: use protobuffers
     * 
     * @return the serialized byte stream
     */
    public byte[] pack() {
        try {
            ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(byteStream);

            out.writeByte(type);
            out.writeByte(errorCode);
            out.write(payload, 0, payload.length);

            out.flush();
            out.close();
            return byteStream.toByteArray();
        } catch (IOException e) {
            return null;
        }
    }
    
    /**
     * Parse a string of the form "command arg1 arg2..." where arg2 may contain
     * additional spaces that are included as part of the argument.
     * @param str
     * @return An array consisting of [command, arg1, arg2].
     */
    public static String[] parseCommandString(String str) {
    	// XXX: this won't handle malformed command strings very well...
    	int afterCommand = str.indexOf(' ');
    	String command = str.substring(0, afterCommand);
    	int afterFilename = str.indexOf(' ', afterCommand + 1);
    	String filename;
    	if(afterFilename < 0) {
    		filename = str.substring(afterCommand + 1);
    		return new String[] { command, filename, "" };
    	} else {
    		filename = str.substring(afterCommand + 1, afterFilename);
    		String contents = str.substring(afterFilename + 1);
    		return new String[] { command, filename, contents };
    	}
    }
}
