import java.util.Collection;

import edu.washington.cs.cse490h.lib.Utility;

/**
 * RPCNode is the highest level of abstraction. He makes receives commands, and
 * makes the corresponding RPCs, using the RIOMessageLayer to transmit the RPC arguments
 * and return value
 *
 */
public class RPCNode extends RIONode {
	
	public static double getFailureRate() { return 0/100.0; }
	public static double getDropRate() { return 5/100.0; }
	public static double getDelayRate() { return 5/100.0; }
	
    private RPCServer server;
    private RPCClient client;

    public RPCNode() {
        super();
        this.server = new RPCServer(this);
        this.client = new RPCClient(this);  
    }
    
    @Override
	public void start() { 
		super.start();
		log("starting up (id=" + instanceID + ")");
	}
    
    @Override
    public void onPeerFailure(int peer, Collection<RIOPacket> failedSends) {
        // all of the failedSends must be AppProtocol.RPC
    	log("was notified of failure of peer #" + peer);
        for (RIOPacket riopkt : failedSends) {
            // TODO: We're breaching abstraction layers here! The RPC layer shouldn't know
            // about RIOPackets...
            RPCPacket pkt = RPCPacket.unpack(riopkt.getPayload());
            if(pkt.getType() == RPCPacket.CALL) {
	            String[] components = Utility.byteArrayToString(pkt.getPayload()).split(" ");
	            this.onRPCError(peer, components[0], components[1], RPCPacket.ERR_TIMEOUT, "Timeout");
            } // ignore RESULT packets
        }
    }

    @Override
    public void onRIOReceive(Integer from, int appProtocol, byte[] msg) {
        if (appProtocol == AppProtocol.RPC) {
            RPCPacket pkt = RPCPacket.unpack(msg);
            if(pkt.getType() == RPCPacket.CALL) {
            	String commandExecuted = server.onRPCReceive(from, pkt);
            	if(!commandExecuted.startsWith("ERROR")) {
            		log("server successfully executed " + commandExecuted);
            	} else {
            		logError("server failed to execute " + commandExecuted.split(" ")[1]);
            	}
            } else if(pkt.getType() == RPCPacket.RESULT) {
            	client.onRPCReceive(from, pkt);
            } else {
            	logError("received unknown RPC type: " + pkt.getType());
            }
        } else {
        	log("received unrecognized protocol: " + appProtocol);
        }
    }
    
    public void onRPCError(int server, String command, String filename, int errorCode, String errorMessage) {
    	logError("ERROR: " + command + " on server " + server + " and file "
    			+ filename + " returned error code " + errorCode + " " + errorMessage);
    }
    
    public void onRPCSuccess(int server, String command, String filename, String result) {
    	log("SUCCESS: " + command + " on server " + server + " and file "
    			+ filename + " executed successfully");
    	if(!result.isEmpty()) // right now, this will only be for a GET; later on, that might not be the case
    		AppUtil.printColored(result, AppUtil.COLOR_PURPLE);
    }

    @Override
    public void onCommand(String command) {
    	try {
	    	String[] args = null;
	    	boolean unrecognized = false;
	        if (command.startsWith("create ")) { // create dest filename
	        	args = AppUtil.splitArgs(command, 3);
	        	client.callCreate(Integer.parseInt(args[1]), args[2]);
	        	
	        } else if (command.startsWith("get ")) { // get dest filename
	        	args = AppUtil.splitArgs(command, 3);
	        	client.callGet(Integer.parseInt(args[1]), args[2]);
	        	
	        } else if (command.startsWith("put ")) { // put dest filename contents
	        	args = AppUtil.splitArgs(command, 4);
	        	client.callPut(Integer.parseInt(args[1]), args[2], args[3]);
	        	
	        }else if (command.startsWith("append ")) { // append dest filename contents
	        	args = AppUtil.splitArgs(command, 4);
	        	client.callAppend(Integer.parseInt(args[1]), args[2], args[3]);
	        	
	        }else if (command.startsWith("delete ")) { // delete dest filename
	        	args = AppUtil.splitArgs(command, 3);
	        	client.callDelete(Integer.parseInt(args[1]), args[2]);
	        	
	        } else {
	        	logError("unrecognized command: " + command.split(" ")[0]);
	        	unrecognized = true;
	        }
	        
	        if(!unrecognized) {
	        	log("client called " + args[0]);
	        }
    	} catch(IllegalArgumentException e) {
    		// This also catches NumberFormatException from Integer.parseInt()
    		logError("bad command syntax");
    	}
    }
}
