#!/bin/bash

if [ "$1" != "" ]; then
    randomSeed="-r $1"   
else
    randomSeed=""
fi

rm -rf storage
rm -f *.log
rm -f *.replay
./execute.pl -s -n RIOTester -f 0 -c scripts/RIOTest $randomSeed

