#!/bin/bash

javac -cp ./jars/plume.jar:./jars/lib.jar proj/*.java

exit
